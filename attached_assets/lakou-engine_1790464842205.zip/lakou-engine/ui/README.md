# Lakou Domino — game screen (React)

Ready-made React components for the in-game screens, built straight from the Figma frames:

| Screen | Figma node | Component |
|---|---|---|
| Game — Points (desktop, ≥1100px) | 1-2 | `LakouGame` |
| Game — Points (phone / tablet, <1100px) | 19-2 | `LakouGame` (switches layout automatically) |
| Hands revealed (leftover tiles face up) | 33-42 | inside `LakouGame` (3 seconds after a hand ends) |
| End of hand (standings 1st–4th) | 17-122 | inside `LakouGame` → `EndOfHand` |
| Final results with crowns | — | inside `LakouGame` → `MatchOver` |
| Seat offer (60-second "Take my seat") | 33-475 | `seatOffer` prop → `SeatOffer` |
| Waitlist panel | 17-2 | `waitlist` prop → `WaitlistPanel` |

No dependencies besides React 18+. No Tailwind. All styles are in `lakou-ui.css` (class names start with `lk-`, so they can't clash with the rest of the app).

## Use it

```tsx
import { LakouGame } from '../lakou-engine/ui';
import '../lakou-engine/ui/lakou-ui.css';

<LakouGame
  view={view}                     // viewFor(match, mySeat) sent by the server — never the full MatchState
  names={['Venloud', 'Jean', 'Nadège', 'Bot 3']}   // by seat
  tableCode="XU62"
  events={lastEvents}             // the events array from the server's last applyAction/autoStep
  eventsKey={eventsCounter}       // +1 every time a new events batch arrives
  turnDeadline={turnEndsAtMs}     // epoch ms when the current player's 30 s end; null during the 5 s pause
  turnMs={30000}
  chat={messages}                 // [{ id, seat, name, text, mine? }]
  onAction={(action) => socket.send({ type: 'action', action })}
  onSendChat={(text) => socket.send({ type: 'chat', text })}
  onNextHand={() => socket.send({ type: 'nextHand' })}
  canStartNextHand={isHost}
  onLeave={leaveTable}
  onPlayAgain={() => socket.send({ type: 'playAgain' })}
  waitlist={{ entries, meId, notify, onToggleNotify, onJoin, onLeave }}
  seatOffer={offerForMe ? { tableName, seatNumber, reason, expiresAt, onTake, onStay } : null}
/>
```

The component is display-only: it never changes game state itself. Tapping a tile calls `onAction` with a legal move taken from `view.legal`. The server runs the engine and sends back a new `view` + `events`.

What it does on its own:
- Lays out the table with the engine's `layoutBoard`, sizes tiles like Figma (max 36px per half on desktop, 21.5px on phone) and keeps them inside the wood.
- Tap a tile: if it fits one end it plays; if it fits several, dashed gold spots appear on the table to choose from.
- Newest tile gets a ring in the player's colour and their name in a small pill.
- "+15" pop and gold glowing pips on the counted ends; "Pass!" flags on seat cards; big banners for DOMINO!, ALL FOUR, GAME LOCKED.
- 30-second countdown bar under your hand (red under 10 s) and a seconds badge on whoever's turn it is.
- End of hand: leftover tiles face up on the table for 3 s, then the standings sheet.
- Tally boxes with hover/tap tooltips.

## Preview

`harness/lakou-table.html` is a standalone build that runs the real engine with bots. Add `?state=mid`, `?state=reveal`, `?state=standings`, `?state=final` or `?state=offer` to jump to a screen. Rebuild with `node ui/harness/build.mjs`.
